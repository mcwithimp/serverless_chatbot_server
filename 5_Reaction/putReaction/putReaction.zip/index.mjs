import { DynamoDBClient, UpdateCommand } from "@aws-sdk/client-dynamodb";
const client = new DynamoDBClient({});

export const handler = async function (event) {
  try {
    const { messageId, reaction } = event.body;
    const type = reaction.liked ? "liked" : "disliked";
    const command = new UpdateCommand({
      TableName: "chat-messages",
      Key: {
        id: messageId,
      },
      UpdateExpression: `set ${type} = :value`,
      ExpressionAttributeValues: {
        ":value": true,
      },
      ReturnValues: "ALL_NEW",
    });
    const result = await client.send(command);
    console.log(`[>>>>>>>>>>>>HERE]: ${result}`);
    return done(null, items);
  } catch (err) {
    return done(err);
  }
};

function done(err, res) {
  if (err) {
    console.error(err);
  }
  return {
    statusCode: err ? "400" : "200",
    body: err ? JSON.stringify(err) : JSON.stringify(res),
    headers: {
      "Content-Type": "application/json",
    },
  };
}
