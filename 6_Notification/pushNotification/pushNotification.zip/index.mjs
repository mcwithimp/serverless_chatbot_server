import { SNSClient } from "@aws-sdk/client-sns";
const client = new SNSClient({});

export const handler = async (event, context) => {
  const body = event.body;
  console.log("[From DynamoDB]: ", body);
  // 환경 변수에서 OpenAI API 키와 데이터베이스 연결 정보를 불러옵니다.
  const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

  try {
    const inputData = JSON.parse(body);
    console.log("[Parsed]: ", inputData);
    if (!inputData) {
      throw new Error("No content provided");
    }

    return done(null, {});
  } catch (err) {
    return done(err);
  }
};

function done(err, res) {
  if (err) {
    console.error(err);
  }
  return {
    statusCode: err ? "400" : "200",
    body: err ? JSON.stringify(err) : JSON.stringify(res),
    headers: {
      "Content-Type": "application/json",
    },
  };
}
